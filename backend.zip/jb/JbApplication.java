package com.jb.jb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JbApplication {

	public static void main(String[] args) {
		SpringApplication.run(JbApplication.class, args);
	}
}
