package com.jb.jb.repositories;

import com.jb.jb.entities.InstaMemory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InstaMemoryRepository extends JpaRepository<InstaMemory, Long> {
}
