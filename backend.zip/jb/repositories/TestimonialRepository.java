package com.jb.jb.repositories;

import com.jb.jb.entities.TestimonialEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TestimonialRepository extends JpaRepository<TestimonialEntity,Long> {

}
