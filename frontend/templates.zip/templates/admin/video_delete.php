<?php
// Include your database connection
include("connection.php");
include 'admin-auth.php';

// Check if the ID is received via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    // Optional: Fetch the video record before deletion if needed (for logging, file deletion, etc.)
    $query = "SELECT * FROM videos WHERE id = $id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Delete the video from the database
        $deleteQuery = "DELETE FROM videos WHERE id = $id";
        if (mysqli_query($conn, $deleteQuery)) {
            // Success: Redirect back to manage page
            header("Location: video_manage.php?status=success");
            exit();
        } else {
            // Error: Redirect back with error
            header("Location: video_manage.php?status=error");
            exit();
        }
    } else {
        // Video not found
        header("Location: video_manage.php?status=notfound");
        exit();
    }
} else {
    // Invalid access
    header("Location: video_manage.php?status=invalid");
    exit();
}
?>
