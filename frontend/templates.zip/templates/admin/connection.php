<?php
$servername = "localhost";
$username = "jeevauser";  // Default for XAMPP
$password = "jeeva007@";      // Default for XAMPP
$database = "mannadb"; // Your database name

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
