<?php
include 'connection.php';

$product_id = $_POST['product_id'];
$product_name = $_POST['product_name'];
$product_description = $_POST['product_description'];
$regular_price = $_POST['regular_price'];
$sku = $_POST['sku'];
$category = $_POST['category'];
$weights = $_POST['weights'] ?? [];
$prices = $_POST['prices'] ?? [];

$weight_array = [];
$price_array = [];

for ($i = 0; $i < count($weights); $i++) {
    $weight_array[] = $weights[$i];
    $price_array[] = [
        "weight" => $weights[$i],
        "price" => $prices[$i]
    ];
}

$weights_json = json_encode($weight_array);
$price_details_json = json_encode($price_array);

$image_path = '';
if (!empty($_FILES['image']['name'])) {
    $target_dir = "img/uploads/";
    $filename = time() . "_" . basename($_FILES["image"]["name"]);
    $target_file = $target_dir . $filename;

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        $image_path = $target_file;
    }
}

// Build query
$sql = "UPDATE products SET 
            product_name = ?, 
            product_description = ?, 
            regular_price = ?, 
            sku = ?, 
            category = ?, 
            weights = ?, 
            price_details = ?";

if ($image_path) {
    $sql .= ", images = ?";
}
$sql .= ", updated_at = NOW() WHERE id = ?";

$stmt = $conn->prepare($sql);

if ($image_path) {
    $stmt->bind_param(
        "ssdsssssi",
        $product_name,
        $product_description,
        $regular_price,
        $sku,
        $category,
        $weights_json,
        $price_details_json,
        $image_path,
        $product_id
    );
} else {
    $stmt->bind_param(
        "ssdssssi",
        $product_name,
        $product_description,
        $regular_price,
        $sku,
        $category,
        $weights_json,
        $price_details_json,
        $product_id
    );
}

if ($stmt->execute()) {
    echo "<script>alert('Product updated successfully'); window.location.href='manage_product.php';</script>";
} else {
    echo "Error: " . $stmt->error;
}
?>
