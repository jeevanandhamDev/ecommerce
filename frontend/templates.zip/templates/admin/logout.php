<?php
session_start();

// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Remove authentication cookie (if set)
if (isset($_COOKIE['admin_logged_in'])) {
    setcookie('admin_logged_in', '', time() - 3600, "/"); // Expire the cookie
}

// Redirect to login page
header("Location: admin-login.php");
exit();
?>
