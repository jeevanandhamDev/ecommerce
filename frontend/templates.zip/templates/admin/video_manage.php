<?php
include 'connection.php';
include 'admin-auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Basic -->
	<meta charset="UTF-8">
	<title>Admin - Manna Chemicals and Drugs Pvt Ltd.,</title>
	<meta name="keywords" content="Manna Chemicals and Drugs Pvt Ltd" />
	<meta name="description" content="Manna Chemicals and Drugs Pvt Ltd">
	<meta name="author" content="Manna Chemicals and Drugs Pvt Ltd">
	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!-- Web Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">
	<!-- Vendor CSS -->
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css" />
	<link rel="stylesheet" href="vendor/animate/animate.compat.css">
	<link rel="stylesheet" href="vendor/font-awesome/css/all.min.css" />
	<link rel="stylesheet" href="vendor/boxicons/css/boxicons.min.css" />
	<link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" />
	<link rel="stylesheet" href="vendor/bootstrap-datepicker/css/bootstrap-datepicker3.css" />
	<!-- Specific Page Vendor CSS -->
	<link rel="stylesheet" href="vendor/jquery-ui/jquery-ui.css" />
	<link rel="stylesheet" href="vendor/jquery-ui/jquery-ui.theme.css" />
	<link rel="stylesheet" href="vendor/bootstrap-multiselect/css/bootstrap-multiselect.css" />
	<link rel="stylesheet" href="vendor/morris/morris.css" />
	<!-- Theme CSS -->
	<link rel="stylesheet" href="css/theme.css" />
	<!-- Theme Custom CSS -->
	<link rel="stylesheet" href="css/custom.css">
	<!-- Head Libs -->
	<script src="vendor/modernizr/modernizr.js"></script>
	<script src="master/style-switcher/style.switcher.localstorage.js"></script>
</head>
<body>
<section class="body">
<header class="header">
				<div class="logo-container">
					<a href="dashboard.php" class="logo">				
						<img src="img/logo.png" width="75" height="35" alt="manna chemicals" />
					</a>
					<div class="d-md-none toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
						<i class="fas fa-bars" aria-label="Toggle sidebar"></i>
					</div>
				</div>
				
			</header>

			<!-- end: header -->
			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<?php include 'menu.php';?>
				<!-- end: sidebar -->
				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Gallery</h2>
						<div class="right-wrapper text-end">
							<ol class="breadcrumbs">
								<li>
									<a href="dashboard.php">
										<i class="bx bx-home-alt"></i>
									</a>
								</li>
								<!-- <li><span>Layouts</span></li>
								<li><span>Default</span></li> -->
							</ol>
							<a class="sidebar-right-toggle" data-open="sidebar-right" title="calender"><i class="fas fa-chevron-left"></i></a>
						</div>
					</header>
					<!-- start: page -->
                    

                    <div class="row">
				<div class="col">
					<section class="card">
						<header class="card-header">
							<h2 class="card-title">Video List</h2>
						</header>
						<div class="card-body">
							<div class="row">
								<?php
								include 'connection.php';
								$sql = "SELECT * FROM videos ORDER BY id DESC";
								$result = mysqli_query($conn, $sql);

								if (mysqli_num_rows($result) > 0) {
									while ($row = mysqli_fetch_assoc($result)) {
										echo '<div class="col-md-6 mb-4">';
										echo '<h5>' . htmlspecialchars($row['title']) . '</h5>';
										echo '<div class="embed-responsive embed-responsive-16by9 mb-2">';
										echo '<iframe class="embed-responsive-item" src="' . htmlspecialchars($row['video_url']) . '" allowfullscreen></iframe>';
										echo '</div>';
										echo '<form method="post" action="video_delete.php" onsubmit="return confirm(\'Are you sure you want to delete this video?\')">';
										echo '<input type="hidden" name="id" value="' . $row['id'] . '">';
										echo '<button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Delete</button>';
										echo '</form>';
										echo '</div>';
									}
								} else {
									echo "<p>No videos found.</p>";
								}
								?>
							</div>
						</div>
					</section>
				</div>
			</div>



					<!-- end: page -->
				</section>
			</div>
			<aside id="sidebar-right" class="sidebar-right">
				<div class="nano">
					<div class="nano-content">
						<a href="#" class="mobile-close d-md-none">
							Collapse <i class="fas fa-chevron-right"></i>
						</a>
						<div class="sidebar-right-wrapper">
							<div class="sidebar-widget widget-calendar">
								<h6>Upcoming Tasks</h6>
								<div data-plugin-datepicker data-plugin-skin="dark"></div>
								<ul>
									<li>
										<time datetime="2023-04-19T00:00+00:00">04/19/2023</time>
										<span>Company Meeting</span>
									</li>
								</ul>
							</div>
							<div class="sidebar-widget widget-friends">
								<h6>Friends</h6>
								<ul>
									<li class="status-online">
										<figure class="profile-picture">
											<img src="img/%21sample-user.jpg" alt="Joseph Doe" class="rounded-circle">
										</figure>
										<div class="profile-info">
											<span class="name">Joseph Doe Junior</span>
											<span class="title">Hey, how are you?</span>
										</div>
									</li>
									<li class="status-online">
										<figure class="profile-picture">
											<img src="img/%21sample-user.jpg" alt="Joseph Doe" class="rounded-circle">
										</figure>
										<div class="profile-info">
											<span class="name">Joseph Doe Junior</span>
											<span class="title">Hey, how are you?</span>
										</div>
									</li>
									<li class="status-offline">
										<figure class="profile-picture">
											<img src="img/%21sample-user.jpg" alt="Joseph Doe" class="rounded-circle">
										</figure>
										<div class="profile-info">
											<span class="name">Joseph Doe Junior</span>
											<span class="title">Hey, how are you?</span>
										</div>
									</li>
									<li class="status-offline">
										<figure class="profile-picture">
											<img src="img/%21sample-user.jpg" alt="Joseph Doe" class="rounded-circle">
										</figure>
										<div class="profile-info">
											<span class="name">Joseph Doe Junior</span>
											<span class="title">Hey, how are you?</span>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</aside>











	
<!-- Vendor -->
<script src="vendor/jquery/jquery.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="vendor/common/common.js"></script>
<script src="vendor/nanoscroller/nanoscroller.js"></script>
<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>
<script src="vendor/jquery-placeholder/jquery.placeholder.js"></script>
<!-- Theme Base, Components and Settings -->
<script src="js/theme.js"></script>
<!-- Theme Custom -->
<script src="js/custom.js"></script>
<!-- Theme Initialization Files -->
<script src="js/theme.init.js"></script>
</body>
</html>