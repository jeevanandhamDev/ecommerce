<?php
// Include database connection
include('connection.php');

// Get the product ID from the URL
$product_id = $_GET['id'];

// Fetch product data
$product_query = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($product_query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product_result = $stmt->get_result();
$product = $product_result->fetch_assoc();

if (!$product) {
    echo "Product not found!";
    exit;
}
?>
<!doctype html>
<html class="fixed">
<head>
    <!-- Basic -->
    <meta charset="UTF-8">
    <title>Admin - Manna Chemicals and Drugs Pvt Ltd.,</title>
    <meta name="keywords" content="Manna Chemicals and Drugs Pvt Ltd" />
    <meta name="description" content="Manna Chemicals and Drugs Pvt Ltd">
    <meta name="author" content="Manna Chemicals and Drugs Pvt Ltd">
    
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    
    <!-- Vendor CSS -->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="vendor/animate/animate.compat.css">
    <link rel="stylesheet" href="vendor/font-awesome/css/all.min.css" />
    <link rel="stylesheet" href="vendor/boxicons/css/boxicons.min.css" />
    <link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="vendor/bootstrap-datepicker/css/bootstrap-datepicker3.css" />
    
    <!-- Theme CSS -->
    <link rel="stylesheet" href="css/theme.css" />
    <link rel="stylesheet" href="css/custom.css">

    <!-- Head Libs -->
    <script src="vendor/modernizr/modernizr.js"></script>
    <script src="master/style-switcher/style.switcher.localstorage.js"></script>
</head>
<body>
<section class="body">
    <!-- start: header -->
    <header class="header">
        <div class="logo-container">
            <a href="dashboard.php" class="logo">                
                <img src="img/logo.png" width="75" height="35" alt="manna chemicals" />
            </a>
            <div class="d-md-none toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
                <i class="fas fa-bars" aria-label="Toggle sidebar"></i>
            </div>
        </div>
    </header>
    <!-- end: header -->

    <div class="inner-wrapper">
        <!-- start: sidebar -->
        <?php include 'menu.php';?>
        <!-- end: sidebar -->

        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Dashboard</h2>
                <div class="right-wrapper text-end">
                    <ol class="breadcrumbs">
                        <li>
                            <a href="dashboard.php">
                                <i class="bx bx-home-alt"></i>
                            </a>
                        </li>
                    </ol>
                    <a class="sidebar-right-toggle" data-open="sidebar-right" title="calender"><i class="fas fa-chevron-left"></i></a>
                </div>
            </header>

            <div class="row">
                <div class="col-lg-11">
				<form action="update_product.php" method="POST" enctype="multipart/form-data">
					<input class="form-control ms-5" type="hidden" name="product_id" value="<?= $product['id'] ?>">

					<label class="form-label ms-5">Product Name</label>
					<input class="form-control ms-5" type="text" name="product_name" value="<?= $product['product_name'] ?>" required>

					<label class="form-label ms-5">Product Description</label>
					<input class="form-control ms-5" type="text" name="product_description" value="<?= $product['product_description'] ?>">

					<label class="form-label ms-5">SKU</label>
					<input class="form-control ms-5" type="text" name="sku" value="<?= $product['sku'] ?>">

					<label class="form-label ms-5">Category</label>
					<input class="form-control ms-5" type="text" name="category" value="<?= $product['category'] ?>" required>

					<label class="form-label ms-5">Regular Price</label>
					<input class="form-control ms-5" type="number" name="regular_price" value="<?= $product['regular_price'] ?>">

					<label class="form-label ms-5">Weights</label>
					<input class="form-control ms-5" type="text" name="weights[]" value="1kg">
					<label class="form-label ms-5">Prices</label>
					<input class="form-control ms-5" type="number" name="prices[]" value="1000">

					<label class="form-label ms-5">Image</label>
					<input class="form-control ms-5" type="file" name="image">

					<input class="form-control ms-5" type="submit" value="Update Product">
				</form>

                </div>
            </div>

            <script>
                function addWeightInput() {
                    let container = document.getElementById("weight-container");
                    let div = document.createElement("div");
                    div.classList.add("d-flex", "mb-2");
                    div.innerHTML = `
                        <input class="form-control ms-5" type="text" name="weights[]" class="form-control mb-2 me-2" placeholder="Enter weight (e.g., 2kg, 500g)" required>
                        <input class="form-control ms-5" type="number" name="prices[]" class="form-control mb-2" placeholder="Enter price" required>
                    `;
                    container.appendChild(div);
                }
            </script>
        </section>
    </div>

    <aside id="sidebar-right" class="sidebar-right">
        <div class="nano">
            <div class="nano-content">
                <a href="#" class="mobile-close d-md-none">
                    Collapse <i class="fas fa-chevron-right"></i>
                </a>
                <div class="sidebar-right-wrapper">
                    <div class="sidebar-widget widget-calendar">
                        <h6>Upcoming Tasks</h6>
                        <div data-plugin-datepicker data-plugin-skin="dark"></div>
                    </div>
                </div>
            </div>
        </div>
    </aside>
</section>

<!-- Vendor -->
<script src="vendor/jquery/jquery.js"></script>
<script src="vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
<script src="vendor/popper/umd/popper.min.html"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="vendor/common/common.js"></script>
<script src="vendor/nanoscroller/nanoscroller.js"></script>
<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>
<script src="vendor/jquery-placeholder/jquery.placeholder.js"></script>

<!-- Specific Page Vendor -->
<script src="vendor/jquery-ui/jquery-ui.js"></script>
<script src="vendor/jqueryui-touch-punch/jquery.ui.touch-punch.js"></script>
<script src="vendor/jquery-validation/jquery.validate.js"></script>
<script src="vendor/select2/js/select2.js"></script>
<script src="vendor/dropzone/dropzone.js"></script>
<script src="vendor/pnotify/pnotify.custom.js"></script>

<!-- Theme Base, Components and Settings -->
<script src="js/theme.js"></script>

<!-- Theme Custom -->
<script src="js/custom.js"></script>

<!-- Theme Initialization Files -->
<script src="js/theme.init.js"></script>
</body>
</html>
