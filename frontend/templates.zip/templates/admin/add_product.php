<?php
// Database connection
include 'connection.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $productName = $_POST['productName'];
    $productDescription = $_POST['productDescription'];
    $regularPrice = $_POST['regularPrice'];
    $salePrice = $_POST['salePrice'] ?? null;
    $sku = $_POST['sku'];
    $stockStatus = $_POST['stockStatus'];
    $weight = $_POST['weight'] ?? null;
    $dimensionsLength = $_POST['dimensionsLength'] ?? null;
    $dimensionsWidth = $_POST['dimensionsWidth'] ?? null;
    $dimensionsHeight = $_POST['dimensionsHeight'] ?? null;
    $purchaseNote = $_POST['purchaseNote'];

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO products (product_name, product_description, regular_price, sale_price, sku, stock_status, weight, dimensions_length, dimensions_width, dimensions_height, purchase_note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssddsdsdddd", $productName, $productDescription, $regularPrice, $salePrice, $sku, $stockStatus, $weight, $dimensionsLength, $dimensionsWidth, $dimensionsHeight, $purchaseNote);

    if ($stmt->execute()) {
        echo "Product added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
    $conn->close();
}
?>
