<?php
// Force session to expire when the browser is closed
ini_set('session.cookie_lifetime', 0);
session_start();

// Set inactivity timeout in seconds (10 minutes here)
$timeoutDuration = 600;

// Auto-logout if timeout is reached
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeoutDuration) {
    session_unset();     // Unset session variables
    session_destroy();   // Destroy session
    header("Location: admin-login.php?timeout=true"); // Redirect with timeout flag
    exit();
}

// Update last activity time stamp
$_SESSION['LAST_ACTIVITY'] = time();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin-login.php"); // Redirect to login page if not authenticated
    exit();
}
?>
