<?php
include 'connection.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $product_description = mysqli_real_escape_string($conn, $_POST['product_description']);
    $sku = mysqli_real_escape_string($conn, $_POST['sku']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);

    $attributes = !empty($_POST['attributes']) ? json_encode($_POST['attributes'], JSON_UNESCAPED_UNICODE) : json_encode([]);
    $weights = !empty($_POST['weights']) ? json_encode($_POST['weights'], JSON_UNESCAPED_UNICODE) : json_encode([]);

    // Store only price with the corresponding weight
    $price_details = [];
    if (!empty($_POST['weights']) && is_array($_POST['weights'])) {
        foreach ($_POST['weights'] as $key => $weight) {
            $price = isset($_POST['prices'][$key]) ? floatval($_POST['prices'][$key]) : null;
            $price_details[] = [
                'weight' => $weight,
                'price' => $price
            ];
        }
    }
    $price_details_json = json_encode($price_details, JSON_UNESCAPED_UNICODE);

    // Image Upload
    $target_dir = "img/uploads/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $imageName = time() . "_" . basename($_FILES["images"]["name"]);
    $target_file = $target_dir . $imageName;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check image validity
    $check = getimagesize($_FILES["images"]["tmp_name"]);
    if ($check === false) {
        die("File is not an image.");
    }

    if (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
        die("Only JPG, JPEG, PNG & GIF files are allowed.");
    }

    if (move_uploaded_file($_FILES["images"]["tmp_name"], $target_file)) {
        $image_path = $target_file;

        // Insert into database (now includes 'category')
        $sql = "INSERT INTO products (product_name, product_description, sku, category, attributes, weights, price_details, images, created_at, updated_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "ssssssss", $product_name, $product_description, $sku, $category, $attributes, $weights, $price_details_json, $image_path);
            if (mysqli_stmt_execute($stmt)) {
                echo "<script>
                    alert('Product added successfully!');
                    window.location.href = 'manage_product.php';
                </script>";
                exit();
            } else {
                echo "Database error: " . mysqli_error($conn);
            }
            mysqli_stmt_close($stmt);
        }
    } else {
        echo "Error uploading file.";
    }
}
?>
