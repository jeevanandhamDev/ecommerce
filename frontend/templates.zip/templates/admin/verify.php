<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $captcha = $_POST['g-recaptcha-response'];
    $secretKey = "6Lc4oQArAAAAAEFWGa-yDBUKH6IMIlEtFrBFIaGV";

    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$captcha");
    $responseKeys = json_decode($response, true);

    if ($responseKeys["success"]) {
        echo "CAPTCHA verified. Proceed with login.";
    } else {
        echo "CAPTCHA verification failed!";
    }
}
?>
