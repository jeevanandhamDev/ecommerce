<?php
include 'connection.php';
include 'admin-auth.php';
?>
<!doctype html>
<html class="fixed">
<head>
	<meta charset="UTF-8">
	<title>Admin - Manna Chemicals and Drugs Pvt Ltd.,</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800|Shadows+Into+Light" rel="stylesheet">
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css" />
	<link rel="stylesheet" href="vendor/font-awesome/css/all.min.css" />
	<link rel="stylesheet" href="css/theme.css" />
	<link rel="stylesheet" href="css/custom.css">
	<script src="vendor/modernizr/modernizr.js"></script>
</head>
<body>
<section class="body">
	<header class="header">
		<div class="logo-container">
			<a href="dashboard.php" class="logo">
				<img src="img/logo.png" width="75" height="35" alt="manna chemicals" />
			</a>
			<div class="d-md-none toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html">
				<i class="fas fa-bars"></i>
			</div>
		</div>
	</header>

	<div class="inner-wrapper">
		<?php include 'menu.php';?>
		<section role="main" class="content-body">
			<header class="page-header">
				<h2>Sales Report</h2>
				<div class="right-wrapper text-end">
					<ol class="breadcrumbs">
						<li><a href="dashboard.php"><i class="bx bx-home-alt"></i></a></li>
					</ol>
					<a class="sidebar-right-toggle"><i class="fas fa-chevron-left"></i></a>
				</div>
			</header>

			<div class="row">
				<div class="col-lg-12">
					<section class="card">
						<div class="card-body">

							<!-- Filter Form -->
							<form method="GET" class="form-inline mb-3">
								<div class="row">
									<div class="col-md-3">
										<select name="month" class="form-control">
											<option value="">-- Select Month --</option>
											<?php
											for ($m = 1; $m <= 12; $m++) {
												$monthName = date('F', mktime(0, 0, 0, $m, 1));
												$selected = (isset($_GET['month']) && $_GET['month'] == $m) ? 'selected' : '';
												echo "<option value='$m' $selected>$monthName</option>";
											}
											?>
										</select>
									</div>
									<div class="col-md-3">
										<select name="year" class="form-control">
											<option value="">-- Select Year --</option>
											<?php
											$currentYear = date('Y');
											for ($y = $currentYear; $y >= $currentYear - 5; $y--) {
												$selected = (isset($_GET['year']) && $_GET['year'] == $y) ? 'selected' : '';
												echo "<option value='$y' $selected>$y</option>";
											}
											?>
										</select>
									</div>
									<div class="col-md-3">
										<button type="submit" class="btn btn-primary">Filter</button>
										<a href="sales_report.php" class="btn btn-secondary">Reset</a>
									</div>
								</div>
							</form>

							<!-- Filter Summary -->
							<?php
							if (!empty($_GET['month']) || !empty($_GET['year'])) {
								$filterMsg = "Showing results for ";
								if (!empty($_GET['month'])) {
									$filterMsg .= date('F', mktime(0, 0, 0, $_GET['month'], 1)) . " ";
								}
								if (!empty($_GET['year'])) {
									$filterMsg .= $_GET['year'];
								}
								echo "<div class='alert alert-info'>$filterMsg</div>";
							}
							?>

							<!-- Sales Table -->
							<table class="table table-bordered table-striped mb-0">
								<thead>
									<tr>
										<th>#</th>
										<th>Order ID</th>
										<th>Customer Name</th>
										<th>Email</th>
										<th>Phone</th>
										<th>GST Number</th>
										<th>Amount</th>
										<th>Status</th>
										<th>Order Date</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$month = isset($_GET['month']) ? (int)$_GET['month'] : '';
									$year = isset($_GET['year']) ? (int)$_GET['year'] : '';

									$where = '';
									if ($month && $year) {
										$where = "WHERE MONTH(created_at) = $month AND YEAR(created_at) = $year";
									} elseif ($year) {
										$where = "WHERE YEAR(created_at) = $year";
									}

									$limit = 10;
									$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
									$offset = ($page - 1) * $limit;

									// Count total
									$totalSql = "SELECT COUNT(*) AS total FROM billing_details $where";
									$totalResult = mysqli_query($conn, $totalSql);
									$totalRow = mysqli_fetch_assoc($totalResult);
									$totalRecords = $totalRow['total'];
									$totalPages = ceil($totalRecords / $limit);

									// Fetch paginated data
									$sql = "SELECT * FROM billing_details $where ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
									$result = mysqli_query($conn, $sql);

									$i = $offset + 1;
									while ($row = mysqli_fetch_assoc($result)) {
										echo "<tr>
											<td>" . $i++ . "</td>
											<td>" . $row['order_id'] . "</td>
											<td>" . $row['first_name'] . " " . $row['last_name'] . "</td>
											<td>" . $row['email'] . "</td>
											<td>" . $row['phone'] . "</td>
											<td>" . $row['gst_number'] . "</td>
											<td>₹" . number_format($row['amount'], 2) . "</td>
											<td><span class='badge bg-success'>" . $row['payment_status'] . "</span></td>
											<td>" . date("d-m-Y h:i A", strtotime($row['created_at'])) . "</td>
										</tr>";
									}
									?>
								</tbody>
							</table>

							<!-- Total Sales -->
							<?php
							$totalAmountSql = "SELECT SUM(amount) AS total_sales FROM billing_details $where";
							$totalAmountResult = mysqli_query($conn, $totalAmountSql);
							$totalAmountRow = mysqli_fetch_assoc($totalAmountResult);
							$totalAmount = $totalAmountRow['total_sales'] ?? 0;

							echo "<h5 class='mt-3' style='color:blue;font-size:2rem;font-family:times-new-roman;justify-content:end;display:flex;'>Total Sales: ₹ " . number_format($totalAmount, 2) . "</h5>";
							?>

							<!-- Pagination -->
							<?php if ($totalPages > 1): ?>
								<nav aria-label="Page navigation" class="mt-3">
									<ul class="pagination justify-content-end">
										<?php for ($p = 1; $p <= $totalPages; $p++): ?>
											<li class="page-item <?= $p == $page ? 'active' : '' ?>">
												<a class="page-link"
												   href="?page=<?= $p ?><?= $month ? "&month=$month" : '' ?><?= $year ? "&year=$year" : '' ?>">
													<?= $p ?>
												</a>
											</li>
										<?php endfor; ?>
									</ul>
								</nav>
							<?php endif; ?>

						</div>
					</section>
				</div>
			</div>
		</section>
	</div>
</section>

<!-- Vendor JS -->
<script src="vendor/jquery/jquery.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="js/theme.js"></script>
<script src="js/custom.js"></script>
<script src="js/theme.init.js"></script>
</body>
</html>
