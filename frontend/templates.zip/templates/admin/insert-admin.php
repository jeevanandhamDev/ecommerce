<?php
include("connection.php"); // Include your database connection

$username = "admin"; // Change this as needed
$password = "admin123"; // Change this as needed

// Hash the password before storing it
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO admin_users (username, password) VALUES (?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $hashed_password);

if ($stmt->execute()) {
    echo "Admin user added successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
